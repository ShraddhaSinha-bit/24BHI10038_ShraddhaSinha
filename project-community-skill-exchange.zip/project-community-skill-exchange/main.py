from fastapi import FastAPI
from database import users_collection, skills_collection, requests_collection, sessions_collection, feedback_collection

app = FastAPI()

@app.get("/")
def home():
    return {"message": "Community Skill Exchange API is running!"}


@app.post("/users")
def create_user(user: dict):
    result = users_collection.insert_one(user)

    return {
        "message": "User created successfully",
        "user_id": str(result.inserted_id)
    }


@app.get("/users")
def get_users():
    users = []

    for user in users_collection.find():
        user["_id"] = str(user["_id"])
        users.append(user)

    return users

from bson import ObjectId

@app.put("/users/{user_id}")
def update_user(user_id: str, updated_data: dict):
    result = users_collection.update_one(
        {"_id": ObjectId(user_id)},
        {"$set": updated_data}
    )

    if result.modified_count == 1:
        return {"message": "User updated successfully"}

    return {"message": "User not found or no changes made"}

@app.delete("/users/{user_id}")
def delete_user(user_id: str):
    result = users_collection.delete_one(
        {"_id": ObjectId(user_id)}
    )

    if result.deleted_count == 1:
        return {"message": "User deleted successfully"}

    return {"message": "User not found"}

@app.post("/skills")
def create_skill(skill: dict):
    result = skills_collection.insert_one(skill)

    return {
        "message": "Skill created successfully",
        "skill_id": str(result.inserted_id)
    }


@app.get("/skills")
def get_skills():
    skills = []

    for skill in skills_collection.find():
        skill["_id"] = str(skill["_id"])
        skills.append(skill)

    return skills


@app.put("/skills/{skill_id}")
def update_skill(skill_id: str, updated_data: dict):
    result = skills_collection.update_one(
        {"_id": ObjectId(skill_id)},
        {"$set": updated_data}
    )

    if result.modified_count == 1:
        return {"message": "Skill updated successfully"}

    return {"message": "Skill not found or no changes made"}


@app.delete("/skills/{skill_id}")
def delete_skill(skill_id: str):
    result = skills_collection.delete_one(
        {"_id": ObjectId(skill_id)}
    )

    if result.deleted_count == 1:
        return {"message": "Skill deleted successfully"}

    return {"message": "Skill not found"}

@app.post("/requests")
def create_request(request: dict):
    result = requests_collection.insert_one(request)

    return {
        "message": "Skill request created successfully",
        "request_id": str(result.inserted_id)
    }


@app.get("/requests")
def get_requests():
    requests = []

    for request in requests_collection.find():
        request["_id"] = str(request["_id"])
        requests.append(request)

    return requests


@app.put("/requests/{request_id}")
def update_request(request_id: str, updated_data: dict):
    result = requests_collection.update_one(
        {"_id": ObjectId(request_id)},
        {"$set": updated_data}
    )

    if result.modified_count == 1:
        return {"message": "Request updated successfully"}

    return {"message": "Request not found or no changes made"}


@app.delete("/requests/{request_id}")
def delete_request(request_id: str):
    result = requests_collection.delete_one(
        {"_id": ObjectId(request_id)}
    )

    if result.deleted_count == 1:
        return {"message": "Request deleted successfully"}

    return {"message": "Request not found"}

@app.post("/sessions")
def create_session(session: dict):
    result = sessions_collection.insert_one(session)

    return {
        "message": "Session created successfully",
        "session_id": str(result.inserted_id)
    }


@app.get("/sessions")
def get_sessions():
    sessions = []

    for session in sessions_collection.find():
        session["_id"] = str(session["_id"])
        sessions.append(session)

    return sessions
@app.put("/sessions/{session_id}")
def update_session(session_id: str, updated_data: dict):
    result = sessions_collection.update_one(
        {"_id": ObjectId(session_id)},
        {"$set": updated_data}
    )

    if result.modified_count == 1:
        return {"message": "Session updated successfully"}

    return {"message": "Session not found or no changes made"}


@app.delete("/sessions/{session_id}")
def delete_session(session_id: str):
    result = sessions_collection.delete_one(
        {"_id": ObjectId(session_id)}
    )

    if result.deleted_count == 1:
        return {"message": "Session deleted successfully"}

    return {"message": "Session not found"}

@app.post("/feedback")
def create_feedback(feedback: dict):
    result = feedback_collection.insert_one(feedback)

    return {
        "message": "Feedback submitted successfully",
        "feedback_id": str(result.inserted_id)
    }


@app.get("/feedback")
def get_feedback():
    feedbacks = []

    for feedback in feedback_collection.find():
        feedback["_id"] = str(feedback["_id"])
        feedbacks.append(feedback)

    return feedbacks

@app.put("/feedback/{feedback_id}")
def update_feedback(feedback_id: str, updated_data: dict):
    result = feedback_collection.update_one(
        {"_id": ObjectId(feedback_id)},
        {"$set": updated_data}
    )

    if result.modified_count == 1:
        return {"message": "Feedback updated successfully"}

    return {"message": "Feedback not found or no changes made"}


@app.delete("/feedback/{feedback_id}")
def delete_feedback(feedback_id: str):
    result = feedback_collection.delete_one(
        {"_id": ObjectId(feedback_id)}
    )

    if result.deleted_count == 1:
        return {"message": "Feedback deleted successfully"}

    return {"message": "Feedback not found"}
