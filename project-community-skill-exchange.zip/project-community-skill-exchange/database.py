from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017")

db = client["community_skill_exchange"]

users_collection = db["users"]
skills_collection = db["skills"]
requests_collection = db["skill_requests"]
sessions_collection = db["sessions"]
feedback_collection = db["feedback"]